# ZegaAI düzenleme notları
- İlk açılışta ad/yaş ekranı eklendi; yaş isteğe bağlı ve sağ üstte Atla var.
- Plus/Premium/hesap sistemi bu kaynak projede bulunmadığından ayrıca kaldırılacak üyelik ekranı yok.
- Uygulama yerel GGUF modelle veya kullanıcının ayarladığı API ile çalışır. API hizmetinin ücretsizliği/limitsizliği uygulama tarafından garanti edilemez.
- Bu çalışma ortamında Android SDK/NDK ve Gradle bulunmadığı için yeni APK derlenemedi. APK klasöründeki dosya temel/orijinal APK'dır, güncellenmiş ekranı içermez.
