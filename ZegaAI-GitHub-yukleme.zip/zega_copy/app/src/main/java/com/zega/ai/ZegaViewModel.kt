package com.zega.ai

import android.app.Application
import androidx.appcompat.app.AppCompatDelegate
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.os.LocaleListCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.zega.ai.ai.EngineRegistry
import com.zega.ai.ai.EngineUnavailable
import com.zega.ai.ai.LocalLlamaEngine
import com.zega.ai.ai.LocalModelManager
import com.zega.ai.ai.RemoteApiEngine
import com.zega.ai.data.Chat
import com.zega.ai.data.ChatMessage
import com.zega.ai.data.ChatRepository
import com.zega.ai.data.SettingsStore
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import java.util.UUID
import java.util.zip.ZipInputStream

class ZegaViewModel(app: Application) : AndroidViewModel(app) {

    private val repo = ChatRepository(app)
    private val store = SettingsStore(app)

    var chats by mutableStateOf<List<Chat>>(emptyList())
        private set
    var currentId by mutableStateOf<String?>(null)
        private set
    var generating by mutableStateOf(false)
        private set

    var themeId by mutableStateOf(store.theme)
        private set
    var customColor by mutableIntStateOf(store.customColor)
        private set
    var language by mutableStateOf(store.language)
        private set
    var aiApiBase by mutableStateOf(store.aiApiBase)
        private set
    var aiApiKey by mutableStateOf(store.aiApiKey)
        private set
    var aiModel by mutableStateOf(store.aiModel)
        private set
    var effort by mutableStateOf(store.effort)
        private set

    var userName by mutableStateOf(store.userName)
        private set
    var userAge by mutableStateOf(store.userAge)
        private set
    var onboardingDone by mutableStateOf(store.onboardingDone)
        private set

    fun finishOnboarding(name: String, age: String?) {
        userName = name.trim()
        userAge = age?.trim().orEmpty()
        store.userName = userName
        store.userAge = userAge
        store.onboardingDone = true
        onboardingDone = true
    }

    fun updateEffort(value: String) { effort = value; store.effort = value }

    /** On-device GGUF model (import, load state). */
    val model = LocalModelManager(app)

    private var job: Job? = null

    val currentChat: Chat? get() = chats.firstOrNull { it.id == currentId }

    init {
        chats = repo.load().sortedByDescending { it.updated }
        EngineRegistry.install(RemoteApiEngine({ aiApiBase }, { aiApiKey }, { aiModel }))
        model.restore()
    }

    // ---- local model ----
    fun importModel(uri: android.net.Uri) = model.import(uri)

    fun removeModel() = model.remove()

    fun reloadModel() = model.reload()

    fun saveOnlineAi(base: String, key: String, modelName: String) {
        aiApiBase = base.trim()
        aiApiKey = key.trim()
        aiModel = modelName.trim()
        store.aiApiBase = aiApiBase
        store.aiApiKey = aiApiKey
        store.aiModel = aiModel
    }

    // ---- settings ----
    fun setTheme(id: String) {
        themeId = id
        store.theme = id
    }

    fun updateCustomColor(argb: Int) {
        customColor = argb
        store.customColor = argb
    }

    fun updateLanguage(tag: String) {
        language = tag
        store.language = tag
        AppCompatDelegate.setApplicationLocales(LocaleListCompat.forLanguageTags(tag))
    }

    // ---- chats ----
    fun newChat() {
        stop()
        currentId = null
    }

    fun selectChat(id: String) {
        stop()
        currentId = id
    }

    fun deleteChat(id: String) {
        if (id == currentId) {
            stop()
            currentId = null
        }
        chats = chats.filter { it.id != id }
        persist()
    }

    fun deleteAllChats() {
        stop()
        currentId = null
        chats = emptyList()
        persist()
    }

    fun storageBytes(): Long = repo.sizeBytes()

    fun stop() {
        job?.cancel()
    }

    fun attachZip(uri: android.net.Uri) {
        if (generating) return
        viewModelScope.launch {
            val result = runCatching {
                val resolver = getApplication<Application>().contentResolver
                val name = resolver.query(uri, null, null, null, null)?.use { c ->
                    val ix = c.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
                    if (ix >= 0 && c.moveToFirst()) c.getString(ix) else null
                } ?: "secilen.zip"
                val entries = mutableListOf<String>()
                resolver.openInputStream(uri)?.use { input ->
                    ZipInputStream(input).use { zip ->
                        var entry = zip.nextEntry
                        while (entry != null && entries.size < 300) {
                            if (!entry.isDirectory) entries += entry.name
                            entry = zip.nextEntry
                        }
                    }
                } ?: error("Dosya okunamadi")
                val hasGradle = entries.any { it.endsWith("build.gradle") || it.endsWith("build.gradle.kts") }
                val hasSettings = entries.any { it.endsWith("settings.gradle") || it.endsWith("settings.gradle.kts") }
                val hasSources = entries.any { it.contains("src/main/java/") || it.contains("src/main/kotlin/") }
                val summary = buildString {
                    append("ZIP dosyanı aldım: $name\n")
                    append("Dosya içeriğinde ${entries.size} dosya girdisi gördüm.\n")
                    append(if (hasGradle && hasSettings && hasSources) "İçerik, Gradle tabanlı bir Java/Kotlin kaynak projesine benziyor. Yine de derlenebilirliği henüz test edilmedi.\n" else "Şu an bunun derlenebilir bir Minecraft mod kaynak projesi olduğunu doğrulayamıyorum.\n")
                    append("İstersen şimdi ZIP'in içeriğini nasıl kontrol edeceğini ve GitHub Actions ile JAR moduna nasıl derleyeceğini adım adım anlatayım. Anlatmamı ister misin?")
                }
                summary
            }.getOrElse { "ZIP dosyasını okuyamadım. Dosyanın bozuk olmadığını ve .zip biçiminde olduğunu kontrol edip tekrar seçebilirsin." }
            val now = System.currentTimeMillis()
            val id = newId()
            val chatId = currentId ?: newId().also { currentId = it }
            val existing = chats.firstOrNull { it.id == chatId }
            val userMsg = ChatMessage(newId(), "user", "[ZIP dosyası eklendi]", now)
            val answer = ChatMessage(id, "assistant", result, now, false)
            chats = if (existing == null) listOf(Chat(chatId, "ZIP dosyası", listOf(userMsg, answer), now)) + chats
                else chats.map { if (it.id == chatId) it.copy(messages = it.messages + userMsg + answer, updated = now) else it }
            persist()
        }
    }

    fun send(text: String) {
        val t = text.trim()
        if (t.isEmpty() || generating) return
        val now = System.currentTimeMillis()
        val userMsg = ChatMessage(newId(), "user", t, now)

        val chatId: String
        val existing = currentId
        if (existing == null || chats.none { it.id == existing }) {
            chatId = newId()
            val title = t.replace('\n', ' ').take(40)
            chats = listOf(Chat(chatId, title, listOf(userMsg), now)) + chats
            currentId = chatId
        } else {
            chatId = existing
            mutate(chatId) { it.copy(messages = it.messages + userMsg, updated = now) }
            chats = chats.sortedByDescending { it.updated }
        }
        persist()

        val history = chats.first { it.id == chatId }.messages
        val assistantId = newId()
        generating = true
        job = viewModelScope.launch {
            var acc = ""
            try {
                EngineRegistry.active().generate(history).collect { token ->
                    acc += token
                    upsertAssistant(chatId, assistantId, acc, false)
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: EngineUnavailable) {
                val message = when {
                    e.code == "API_KEY_MISSING" -> localHelperReply(t)
                    e.code == "API_ENDPOINT_INVALID" -> "API adresi hatalı görünüyor. ZIP inceleme özelliğini kullanmak için mesaj kutusunun yanındaki ataç simgesinden ZIP dosyanı seçebilirsin."
                    e.code.startsWith("API_ERROR_") -> "Çevrim içi servis şu anda yanıt vermedi. ZIP dosyanı ataç simgesinden seçersen temel dosya kontrolünü API anahtarı olmadan yapabilirim."
                    else -> localHelperReply(t)
                }
                upsertAssistant(chatId, assistantId, message, false)
            } catch (e: Exception) {
                upsertAssistant(chatId, assistantId, localHelperReply(t), false)
            } finally {
                generating = false
                persist()
            }
        }
    }

    private fun localHelperReply(userText: String): String {
        val q = userText.lowercase()
        return when {
            q.contains("jar") || q.contains("mod") || q.contains("minecraft") || q.contains("github") ->
                "Minecraft mod ZIP'ini incelememi istiyorsan mesaj kutusunun solundaki ataç simgesine basıp ZIP dosyanı seç. Dosya adlarını ve Gradle/Fabric proje yapısını kontrol edip sana ne içerdiğini açıklayacağım. Ardından ‘GitHub'dan JAR moda dönüştürmeyi anlatmamı ister misin?’ diye soracağım. Bu temel ZIP kontrolü API anahtarı istemez."
            q.contains("merhaba") || q.contains("selam") || q == "sa" ->
                "Nasıl yardımcı olabilirim?"
            else ->
                "Şu anda çevrim içi yapay zekâ bağlantısı yapılandırılmamış. Yine de Minecraft mod ZIP'ini ataç simgesinden yükleyebilirsin: dosya yapısını yerel olarak kontrol edip ne içerdiğini ve GitHub Actions ile JAR'a dönüştürmeye uygun olup olmadığını açıklayabilirim."
        }
    }

    private fun upsertAssistant(chatId: String, msgId: String, text: String, error: Boolean) {
        mutate(chatId) { c ->
            val msg = ChatMessage(msgId, "assistant", text, System.currentTimeMillis(), error)
            val exists = c.messages.any { it.id == msgId }
            c.copy(
                messages = if (exists) c.messages.map { if (it.id == msgId) msg else it } else c.messages + msg,
                updated = System.currentTimeMillis()
            )
        }
    }

    private fun mutate(id: String, f: (Chat) -> Chat) {
        chats = chats.map { if (it.id == id) f(it) else it }
    }

    private fun persist() {
        try {
            repo.save(chats)
        } catch (_: Exception) {
        }
    }

    private fun newId(): String = UUID.randomUUID().toString()
}
