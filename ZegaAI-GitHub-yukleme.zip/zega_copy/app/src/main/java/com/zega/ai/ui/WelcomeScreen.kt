package com.zega.ai.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.zega.ai.ZegaViewModel

@Composable
fun WelcomeScreen(vm: ZegaViewModel) {
    var name by remember { mutableStateOf(vm.userName) }
    var age by remember { mutableStateOf(vm.userAge) }
    Box(Modifier.fillMaxSize()) {
        if (name.isNotBlank() && age.isBlank()) {
            TextButton(onClick = { vm.finishOnboarding(name, null) },
                modifier = Modifier.align(Alignment.TopEnd).padding(12.dp)) {
                Text("Atla")
            }
        }
        Column(Modifier.align(Alignment.Center).padding(24.dp).fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Text("ZegaAI", style = MaterialTheme.typography.headlineLarge)
            Text("Adınızı ve yaşınızı girin", style = MaterialTheme.typography.titleMedium)
            OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Adınız") },
                singleLine = true, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = age, onValueChange = { age = it.filter(Char::isDigit).take(3) },
                label = { Text("Yaşınız") }, singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth())
            Button(onClick = { vm.finishOnboarding(name, age.takeIf { it.isNotBlank() }) }, enabled = name.isNotBlank(), modifier = Modifier.fillMaxWidth()) {
                Text("Devam et")
            }
        }
    }
}
