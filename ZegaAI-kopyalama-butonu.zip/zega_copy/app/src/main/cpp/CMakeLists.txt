cmake_minimum_required(VERSION 3.22.1)
project(zega_llm C CXX)

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_POSITION_INDEPENDENT_CODE ON)

# Always optimise the native engine, even in the Gradle "debug" variant:
# an unoptimised llama.cpp is unusably slow on a phone.
if (NOT CMAKE_BUILD_TYPE OR CMAKE_BUILD_TYPE STREQUAL "Debug")
    set(CMAKE_BUILD_TYPE Release CACHE STRING "" FORCE)
endif()

# ---- llama.cpp / ggml options (static, CPU only, no extra tools) ----
set(BUILD_SHARED_LIBS OFF CACHE BOOL "" FORCE)
set(LLAMA_BUILD_COMMON   OFF CACHE BOOL "" FORCE)
set(LLAMA_BUILD_TESTS    OFF CACHE BOOL "" FORCE)
set(LLAMA_BUILD_TOOLS    OFF CACHE BOOL "" FORCE)
set(LLAMA_BUILD_EXAMPLES OFF CACHE BOOL "" FORCE)
set(LLAMA_BUILD_SERVER   OFF CACHE BOOL "" FORCE)
set(LLAMA_BUILD_APP      OFF CACHE BOOL "" FORCE)
set(LLAMA_CURL    OFF CACHE BOOL "" FORCE)
set(LLAMA_OPENSSL OFF CACHE BOOL "" FORCE)
set(LLAMA_BUILD_IS_DEV OFF CACHE BOOL "" FORCE)
set(GGML_OPENMP OFF CACHE BOOL "" FORCE)
set(GGML_NATIVE OFF CACHE BOOL "" FORCE)
set(GGML_BUILD_TESTS    OFF CACHE BOOL "" FORCE)
set(GGML_BUILD_EXAMPLES OFF CACHE BOOL "" FORCE)

if (ANDROID_ABI STREQUAL "arm64-v8a")
    # Baseline for 2018+ phones. LocalModelManager checks /proc/cpuinfo for
    # dotprod + fp16 before loading a model, so older CPUs get a clear
    # message instead of an illegal-instruction crash.
    set(GGML_CPU_ARM_ARCH "armv8.2-a+dotprod+fp16" CACHE STRING "" FORCE)
endif()

add_subdirectory(llama.cpp llama_build)

add_library(zega_llm SHARED llama_jni.cpp)
target_include_directories(zega_llm PRIVATE llama.cpp/include llama.cpp/ggml/include)
target_link_libraries(zega_llm PRIVATE llama ggml)
if (ANDROID)
    target_link_libraries(zega_llm PRIVATE log android)
    # Android 15+ devices may use 16 KB memory pages.
    target_link_options(zega_llm PRIVATE -Wl,-z,max-page-size=16384)
endif()
