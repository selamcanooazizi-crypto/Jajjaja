package com.zega.ai.ai

import com.zega.ai.data.ChatMessage
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/** [AiEngine] that runs the GGUF model loaded by [LocalModelManager] fully on-device. */
class LocalLlamaEngine(
    private val models: LocalModelManager,
    private val languageTag: () -> String
) : AiEngine {

    override val id: String = "llama.cpp"

    override fun generate(history: List<ChatMessage>): Flow<String> = flow {
        if (!LlamaBridge.available) throw EngineUnavailable("ENGINE_MISSING")

        // Wait for a running model load (startup / just imported); then require a loaded model.
        models.awaitLoad()
        if (!models.isReady) {
            throw EngineUnavailable(if (models.state == LocalModelManager.State.NONE) "NO_MODEL" else "MODEL_FAILED")
        }

        val roles = ArrayList<String>()
        val contents = ArrayList<String>()
        roles += "system"
        contents += SystemPrompts.forLanguage(languageTag())
        for (m in history) {
            if (m.isError || m.text.isBlank()) continue
            if (m.role != "user" && m.role != "assistant") continue
            roles += m.role
            contents += m.text
        }
        if (roles.last() != "user") throw EngineUnavailable("ERROR:empty conversation")

        val bytes = Channel<ByteArray>(Channel.UNLIMITED)
        var nativeError: String? = null

        coroutineScope {
            val worker = launch(Dispatchers.Default) {
                try {
                    nativeError = LlamaBridge.generate(
                        roles.toTypedArray(),
                        contents.toTypedArray(),
                        MAX_NEW_TOKENS,
                        TokenCallback { b ->
                            bytes.trySend(b)
                            isActive
                        }
                    )
                } finally {
                    bytes.close()
                }
            }
            try {
                // Decode incrementally so a multi-byte character split across two
                // callbacks is never turned into garbage.
                val decoder = Utf8Stream()
                for (b in bytes) {
                    val s = decoder.feed(b)
                    if (s.isNotEmpty()) emit(s)
                }
                val tail = decoder.finish()
                if (tail.isNotEmpty()) emit(tail)
            } finally {
                // Cancelled (stop button) while native code is still running: ask it to return.
                if (worker.isActive) LlamaBridge.stop()
            }
        }

        nativeError?.let { err ->
            when (err) {
                "NO_MODEL" -> throw EngineUnavailable("NO_MODEL")
                "CONTEXT_TOO_LONG" -> throw EngineUnavailable("CONTEXT_TOO_LONG")
                else -> throw EngineUnavailable("ERROR:$err")
            }
        }
    }

    companion object {
        const val MAX_NEW_TOKENS = 1024
    }
}

/** Incremental UTF-8 decoder that holds back an incomplete trailing sequence. */
private class Utf8Stream {
    private var carry = ByteArray(0)

    fun feed(chunk: ByteArray): String {
        val all = carry + chunk
        val cut = completePrefix(all)
        carry = all.copyOfRange(cut, all.size)
        return String(all, 0, cut, Charsets.UTF_8)
    }

    fun finish(): String {
        val s = if (carry.isEmpty()) "" else String(carry, Charsets.UTF_8)
        carry = ByteArray(0)
        return s
    }

    private fun completePrefix(b: ByteArray): Int {
        val n = b.size
        var back = 1
        while (back <= minOf(4, n)) {
            val c = b[n - back].toInt() and 0xFF
            if (c and 0xC0 == 0x80) {
                back++
                continue
            }
            val need = when {
                c and 0x80 == 0 -> 1
                c and 0xE0 == 0xC0 -> 2
                c and 0xF0 == 0xE0 -> 3
                c and 0xF8 == 0xF0 -> 4
                else -> return n
            }
            return if (back >= need) n else n - back
        }
        return n
    }
}

object SystemPrompts {
    fun forLanguage(tag: String): String {
        val lang = when (tag.lowercase().substringBefore('-')) {
            "en" -> "English"
            "de" -> "German"
            "ru" -> "Russian"
            "fr" -> "French"
            "es" -> "Spanish"
            "ar" -> "Arabic"
            "it" -> "Italian"
            "pt" -> "Portuguese"
            else -> null
        }
        return if (lang == null) {
            "Sen ZegaAİ'sin; kullanıcının telefonunda internetsiz, tamamen cihaz üzerinde çalışan bir yapay zekâ asistanısın. " +
                "Her zaman Türkçe cevap ver; kullanıcı açıkça başka bir dil istemedikçe dili değiştirme. " +
                "Cevapların doğru, açık ve gereksiz uzatmadan olsun. Bilmediğin bir şeyi uydurma; bilmediğini söyle."
        } else {
            "You are ZegaAİ, an AI assistant running fully offline on the user's phone. " +
                "Always answer in $lang unless the user explicitly asks for another language. " +
                "Keep answers accurate and clear without unnecessary length. If you do not know something, say so instead of inventing it."
        }
    }
}
