package com.zega.ai.ai

import android.app.ActivityManager
import android.content.Context
import android.net.Uri
import android.os.StatFs
import android.provider.OpenableColumns
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.zega.ai.data.SettingsStore
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.launch
import java.io.File
import java.io.IOException

/**
 * Owns the GGUF model file (copied into app-private storage) and its loaded state.
 * All state is Compose state so screens can read it directly.
 */
class LocalModelManager(context: Context) {

    enum class State { NONE, COPYING, LOADING, READY, ERROR }

    private val app = context.applicationContext
    private val store = SettingsStore(app)
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val modelsDir = File(app.filesDir, "models")

    var state by mutableStateOf(State.NONE)
        private set
    var name by mutableStateOf<String?>(null)
        private set
    var sizeBytes by mutableLongStateOf(0L)
        private set
    /** 0..100 while [state] == COPYING. */
    var progress by mutableIntStateOf(0)
        private set
    /** Error code resolved to a localized string by the UI: NOT_GGUF, TOO_BIG, NO_SPACE, CPU, ENGINE_MISSING, CRASHED, LOAD, COPY. */
    var errorCode by mutableStateOf<String?>(null)
        private set
    var errorArg by mutableStateOf("")
        private set

    val isReady: Boolean get() = state == State.READY

    @Volatile private var job: Job? = null

    /** Suspends while a copy/load is running. */
    suspend fun awaitLoad() {
        job?.join()
    }

    /** Called once at app start: loads the previously imported model in the background. */
    fun restore() {
        val path = store.modelPath
        if (path.isEmpty()) return
        val f = File(path)
        if (!f.isFile) {
            clearStored()
            return
        }
        name = store.modelName.ifEmpty { f.name }
        sizeBytes = f.length()
        if (store.modelLoading) {
            // The previous process died while loading this model: do not retry automatically.
            store.modelLoading = false
            fail("CRASHED", "")
            return
        }
        startLoad(f)
    }

    /** Copies the chosen document into private storage, validates it and loads it. */
    fun import(uri: Uri) {
        val previous = job
        job = scope.launch {
            previous?.cancelAndJoin()
            doImport(uri)
        }
    }

    /** Unloads and deletes the current model. */
    fun remove() {
        val previous = job
        job = scope.launch {
            previous?.cancelAndJoin()
            LlamaBridge.stopAndUnload()
            deleteModelFiles()
            clearStored()
        }
    }

    /** Retries loading the stored model (e.g. after an error or a crash guard trip). */
    fun reload() {
        val f = File(store.modelPath)
        if (!f.isFile) {
            clearStored()
            return
        }
        store.modelLoading = false
        startLoad(f)
    }

    // ------------------------------------------------------------------ internals

    private suspend fun doImport(uri: Uri) {
        try {
            errorCode = null
            val cr = app.contentResolver
            var display = "model.gguf"
            var size = -1L
            cr.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    c.getString(0)?.let { display = it }
                    if (!c.isNull(1)) size = c.getLong(1)
                }
            }
            display = display.replace(Regex("[^A-Za-z0-9._-]"), "_").ifEmpty { "model.gguf" }

            // 1) must be a GGUF file
            val input = cr.openInputStream(uri) ?: throw IOException("cannot open file")
            input.use { ins ->
                val magic = ByteArray(4)
                var read = 0
                while (read < 4) {
                    val n = ins.read(magic, read, 4 - read)
                    if (n < 0) break
                    read += n
                }
                if (read < 4 || String(magic, Charsets.ISO_8859_1) != "GGUF") {
                    reject("NOT_GGUF", "")
                    return
                }
            }

            // 2) memory / storage sanity checks before copying gigabytes
            if (size > 0) {
                if (tooBigForRam(size)) {
                    reject("TOO_BIG", formatBytes(size))
                    return
                }
                modelsDir.mkdirs()
                val free = try {
                    StatFs(app.filesDir.path).availableBytes
                } catch (e: Exception) {
                    Long.MAX_VALUE
                }
                if (free < size + 100L * 1024 * 1024) {
                    reject("NO_SPACE", formatBytes(size))
                    return
                }
            }

            // 3) release the old model first (frees RAM, and its file may be replaced)
            LlamaBridge.stopAndUnload()
            deleteModelFiles()
            clearStored(keepState = true)
            modelsDir.mkdirs()

            // 4) copy with progress
            state = State.COPYING
            progress = 0
            name = display
            sizeBytes = if (size > 0) size else 0L
            val tmp = File(modelsDir, "$display.part")
            val dest = File(modelsDir, display)
            try {
                cr.openInputStream(uri)!!.use { ins ->
                    tmp.outputStream().use { out ->
                        val buf = ByteArray(1 shl 20)
                        var total = 0L
                        var lastPct = -1
                        while (true) {
                            currentCoroutineContext().ensureActive()
                            val n = ins.read(buf)
                            if (n < 0) break
                            out.write(buf, 0, n)
                            total += n
                            if (size > 0) {
                                val pct = (total * 100 / size).toInt().coerceIn(0, 100)
                                if (pct != lastPct) {
                                    lastPct = pct
                                    progress = pct
                                }
                            }
                        }
                        sizeBytes = total
                    }
                }
                if (!tmp.renameTo(dest)) throw IOException("rename failed")
            } catch (e: kotlinx.coroutines.CancellationException) {
                tmp.delete()
                throw e
            } catch (e: Exception) {
                tmp.delete()
                dest.delete()
                fail("COPY", e.message ?: "")
                return
            }

            if (tooBigForRam(dest.length())) {
                dest.delete()
                fail("TOO_BIG", formatBytes(dest.length()))
                return
            }

            store.modelPath = dest.absolutePath
            store.modelName = display
            runLoad(dest)
        } catch (e: kotlinx.coroutines.CancellationException) {
            throw e
        } catch (e: Exception) {
            fail("COPY", e.message ?: "")
        }
    }

    private fun startLoad(f: File) {
        val previous = job
        job = scope.launch {
            previous?.join()
            runLoad(f)
        }
    }

    /** Blocking; runs on the manager's background dispatcher. */
    private fun runLoad(f: File) {
        errorCode = null
        if (!LlamaBridge.available) {
            fail("ENGINE_MISSING", "")
            return
        }
        if (!cpuSupported()) {
            fail("CPU", "")
            return
        }
        state = State.LOADING
        name = store.modelName.ifEmpty { f.name }
        sizeBytes = f.length()
        store.modelLoading = true // crash guard, see SettingsStore
        val err = try {
            LlamaBridge.load(f.absolutePath, contextSize(), threadCount())
        } catch (t: Throwable) {
            t.message ?: "native error"
        }
        store.modelLoading = false
        if (err == null) {
            errorCode = null
            state = State.READY
        } else {
            fail("LOAD", err)
        }
    }

    /** A file was refused before anything changed: keep the currently loaded model, just show why. */
    private fun reject(code: String, arg: String) {
        errorCode = code
        errorArg = arg
    }

    private fun fail(code: String, arg: String) {
        errorCode = code
        errorArg = arg
        state = State.ERROR
        // Nothing usable is loaded in these cases; keep the file (if any) so the user can retry/remove.
        if (store.modelPath.isEmpty()) {
            name = null
            sizeBytes = 0L
        }
    }

    private fun clearStored(keepState: Boolean = false) {
        store.modelPath = ""
        store.modelName = ""
        store.modelLoading = false
        if (!keepState) {
            name = null
            sizeBytes = 0L
            errorCode = null
            errorArg = ""
            state = State.NONE
        }
    }

    private fun deleteModelFiles() {
        modelsDir.listFiles()?.forEach { it.delete() }
    }

    private fun totalRam(): Long {
        val am = app.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        return ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }.totalMem
    }

    /** Weights are memory-mapped, but a model much larger than RAM would be killed by the OS. */
    private fun tooBigForRam(modelBytes: Long): Boolean = modelBytes > totalRam() * 0.75

    private fun contextSize(): Int {
        val gb = totalRam() / (1024.0 * 1024.0 * 1024.0)
        return when {
            gb >= 11 -> 8192
            gb >= 7 -> 4096
            gb >= 4 -> 2048
            else -> 1024
        }
    }

    private fun threadCount(): Int {
        val cores = Runtime.getRuntime().availableProcessors()
        return (cores - 2).coerceIn(2, 4)
    }

    /**
     * The native library is built for armv8.2-a + dotprod + fp16. On a CPU without those
     * the process would die with SIGILL, so refuse politely instead.
     */
    private fun cpuSupported(): Boolean {
        val abi = android.os.Build.SUPPORTED_ABIS.firstOrNull() ?: return true
        if (abi != "arm64-v8a") return true
        return try {
            val feat = File("/proc/cpuinfo").readLines()
                .firstOrNull { it.startsWith("Features") }
                ?.substringAfter(':')?.trim()?.split(Regex("\\s+")).orEmpty()
            if (feat.isEmpty()) true else ("asimddp" in feat && "asimdhp" in feat)
        } catch (e: Exception) {
            true
        }
    }

    companion object {
        fun formatBytes(b: Long): String {
            val gb = b / (1024.0 * 1024.0 * 1024.0)
            return if (gb >= 1.0) String.format(java.util.Locale.US, "%.1f GB", gb)
            else String.format(java.util.Locale.US, "%.0f MB", b / (1024.0 * 1024.0))
        }
    }
}
