package com.zega.ai.ai

import com.zega.ai.data.ChatMessage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** OpenAI-compatible online backend. The product identity remains ZegaAI; provider is configurable. */
class RemoteApiEngine(
    private val endpoint: () -> String,
    private val apiKey: () -> String,
    private val model: () -> String
) : AiEngine {
    override val id: String = "zegaai-online"

    override fun generate(history: List<ChatMessage>): Flow<String> = flow {
        val key = apiKey().trim()
        if (key.isEmpty()) throw EngineUnavailable("API_KEY_MISSING")
        val url = endpoint().trim()
        if (!url.startsWith("https://") && !url.startsWith("http://")) throw EngineUnavailable("API_ENDPOINT_INVALID")
        val result = withContext(Dispatchers.IO) {
            val conn = (URL(url).openConnection() as HttpURLConnection)
            try {
                conn.requestMethod = "POST"
                conn.connectTimeout = 20000
                conn.readTimeout = 90000
                conn.doOutput = true
                conn.setRequestProperty("Content-Type", "application/json; charset=utf-8")
                conn.setRequestProperty("Authorization", "Bearer $key")
                val messages = JSONArray()
                messages.put(JSONObject().put("role", "system").put("content", "Sen ZegaAİ adlı Türkçe konuşan yardımcı asistansın. Minecraft mod geliştirme, Fabric, Gradle ve JAR derleme konularında adım adım yardımcı ol. Bir ZIP'in JAR'a çevrilebilmesi için içinde derlenebilir kaynak proje ve build dosyaları bulunması gerektiğini açıkça belirt. Dosyayı gerçekten işlemediysen işlediğini iddia etme."))
                history.filter { !it.isError && (it.role == "user" || it.role == "assistant") }.takeLast(24).forEach {
                    messages.put(JSONObject().put("role", it.role).put("content", it.text))
                }
                val body = JSONObject().put("model", model().ifBlank { "gpt-4o-mini" }).put("messages", messages).put("temperature", 0.4)
                conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
                val code = conn.responseCode
                val stream = if (code in 200..299) conn.inputStream else conn.errorStream
                val response = stream.bufferedReader().use { it.readText() }
                if (code !in 200..299) throw EngineUnavailable("API_ERROR_$code: ${response.take(500)}")
                val json = JSONObject(response)
                json.getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content")
            } finally { conn.disconnect() }
        }
        emit(result)
    }
}
