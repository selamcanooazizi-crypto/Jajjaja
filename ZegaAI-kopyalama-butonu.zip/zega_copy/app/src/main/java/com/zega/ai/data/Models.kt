package com.zega.ai.data

data class ChatMessage(
    val id: String,
    val role: String, // "user" or "assistant"
    val text: String,
    val time: Long,
    val isError: Boolean = false
)

data class Chat(
    val id: String,
    val title: String,
    val messages: List<ChatMessage>,
    val updated: Long
)
