package com.zega.ai.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.zega.ai.ZegaViewModel

@Composable
fun OnlineAiSettingsScreen(vm: ZegaViewModel, onBack: () -> Unit) {
    var endpoint by remember { mutableStateOf(vm.aiApiBase) }
    var key by remember { mutableStateOf(vm.aiApiKey) }
    var model by remember { mutableStateOf(vm.aiModel) }
    SubScaffold("ZegaAİ çevrim içi yapay zekâ", onBack) {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Text("ZegaAİ adı ve arayüzü korunur. Bu ekran OpenAI-uyumlu bir API sunucusuna bağlanır. Kendi sunucun veya bir sağlayıcıdan API anahtarı gerekir; anahtar olmadan sohbet yanıtı üretilemez.", style = MaterialTheme.typography.bodyMedium)
            OutlinedTextField(endpoint, { endpoint = it }, modifier = Modifier.fillMaxWidth(), label = { Text("API adresi") }, singleLine = true)
            OutlinedTextField(model, { model = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Model adı") }, singleLine = true)
            OutlinedTextField(key, { key = it }, modifier = Modifier.fillMaxWidth(), label = { Text("API anahtarı") }, singleLine = true)
            Button(onClick = { vm.saveOnlineAi(endpoint, key, model); onBack() }, modifier = Modifier.fillMaxWidth()) { Text("Kaydet") }
            Text("Varsayılan adres OpenAI uyumlu sohbet uç noktasıdır. Başka servis kullanıyorsan onun uyumlu adresini ve model adını gir.", style = MaterialTheme.typography.bodySmall)
        }
    }
}
