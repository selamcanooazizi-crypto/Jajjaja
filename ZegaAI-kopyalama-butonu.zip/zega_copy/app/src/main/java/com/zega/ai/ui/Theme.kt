package com.zega.ai.ui

import android.app.Activity
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

data class ZegaPalette(
    val bg: Color,
    val surface: Color,
    val onBg: Color,
    val accent: Color,
    val onAccent: Color,
    val light: Boolean
)

private fun dark(bg: Long, surface: Long, accent: Long) = ZegaPalette(
    bg = Color(bg),
    surface = Color(surface),
    onBg = Color(0xFFECECEC),
    accent = Color(accent),
    onAccent = Color(0xFF000000),
    light = false
)

val THEME_IDS = listOf("BLACK", "DARKGRAY", "DARKBLUE", "PURPLE", "GREEN", "WHITE", "CUSTOM")

fun paletteFor(id: String, custom: Int): ZegaPalette = when (id) {
    "DARKGRAY" -> dark(0xFF1E1E1E, 0xFF2B2B2B, 0xFF8AB4FF)
    "DARKBLUE" -> dark(0xFF0B1530, 0xFF14224A, 0xFF5AA9FF)
    "PURPLE" -> dark(0xFF1A0B2E, 0xFF2A1650, 0xFFB388FF)
    "GREEN" -> dark(0xFF06170D, 0xFF0F2A1A, 0xFF4ADE80)
    "WHITE" -> ZegaPalette(
        bg = Color(0xFFFFFFFF),
        surface = Color(0xFFF1F3F6),
        onBg = Color(0xFF111111),
        accent = Color(0xFF3B5BDB),
        onAccent = Color(0xFFFFFFFF),
        light = true
    )
    "CUSTOM" -> {
        val bg = Color(custom)
        val light = bg.luminance() > 0.5f
        val on = if (light) Color(0xFF111111) else Color(0xFFF2F2F2)
        ZegaPalette(bg, lerp(bg, on, 0.10f), on, on, bg, light)
    }
    else -> dark(0xFF000000, 0xFF121212, 0xFF8AB4FF) // BLACK (default)
}

@Composable
fun ZegaTheme(themeId: String, customColor: Int, content: @Composable () -> Unit) {
    val p = paletteFor(themeId, customColor)
    val scheme = if (p.light) {
        lightColorScheme(
            primary = p.accent,
            onPrimary = p.onAccent,
            background = p.bg,
            onBackground = p.onBg,
            surface = p.surface,
            onSurface = p.onBg,
            surfaceVariant = p.surface,
            onSurfaceVariant = p.onBg.copy(alpha = 0.7f),
            outline = p.onBg.copy(alpha = 0.3f)
        )
    } else {
        darkColorScheme(
            primary = p.accent,
            onPrimary = p.onAccent,
            background = p.bg,
            onBackground = p.onBg,
            surface = p.surface,
            onSurface = p.onBg,
            surfaceVariant = p.surface,
            onSurfaceVariant = p.onBg.copy(alpha = 0.7f),
            outline = p.onBg.copy(alpha = 0.3f)
        )
    }

    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window
            if (window != null) {
                val c = WindowCompat.getInsetsController(window, view)
                c.isAppearanceLightStatusBars = p.light
                c.isAppearanceLightNavigationBars = p.light
            }
        }
    }
    MaterialTheme(colorScheme = scheme, content = content)
}
