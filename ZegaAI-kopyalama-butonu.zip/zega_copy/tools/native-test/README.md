# Native engine test (runs on a normal Linux PC, no Android needed)

Builds the same `llama_jni.cpp` against llama.cpp for the host, creates a tiny random GGUF and drives
the JNI functions from Java (load errors, streaming, UTF-8 chunking, KV reuse, stop, context trimming, unload).

    JH=$(dirname $(dirname $(readlink -f $(which javac))))
    cmake -G Ninja -S app/src/main/cpp -B /tmp/hb -DCMAKE_BUILD_TYPE=Release -DGGML_NATIVE=ON \
          -DCMAKE_CXX_FLAGS="-I$JH/include -I$JH/include/linux"
    ninja -C /tmp/hb zega_llm
    cd tools/native-test && python3 mkgguf.py tiny.gguf
    javac -d . com/zega/ai/ai/*.java Test.java && java -cp . Test /tmp/hb/libzega_llm.so tiny.gguf
