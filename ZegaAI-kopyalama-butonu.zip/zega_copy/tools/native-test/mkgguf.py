import struct, random, sys
random.seed(1)
def s(x): b=x.encode(); return struct.pack('<Q',len(b))+b
def kv(k,t,v):
    o=s(k)+struct.pack('<I',t)
    if t==4: o+=struct.pack('<I',v)
    elif t==6: o+=struct.pack('<f',v)
    elif t==7: o+=struct.pack('<?',v)
    elif t==8: o+=s(v)
    elif t==9:
        et,items=v; o+=struct.pack('<IQ',et,len(items))
        for it in items:
            o+= s(it) if et==8 else struct.pack('<f',it) if et==6 else struct.pack('<i',it)
    return o
toks=["<unk>","<s>","</s>","<|im_start|>","<|im_end|>"]+["<0x%02X>"%i for i in range(256)]
types=[2,3,3,3,3]+[6]*256
V=len(toks); D=64; F=128; L=2
tmpl="{% for m in messages %}{{'<|im_start|>' + m['role'] + '\n' + m['content'] + '<|im_end|>' + '\n'}}{% endfor %}{% if add_generation_prompt %}{{ '<|im_start|>assistant\n' }}{% endif %}"
kvs=[kv("general.architecture",8,"llama"),kv("general.name",8,"tiny"),
 kv("llama.context_length",4,512),kv("llama.embedding_length",4,D),kv("llama.block_count",4,L),
 kv("llama.feed_forward_length",4,F),kv("llama.attention.head_count",4,4),kv("llama.attention.head_count_kv",4,4),
 kv("llama.attention.layer_norm_rms_epsilon",6,1e-5),kv("llama.rope.dimension_count",4,16),
 kv("tokenizer.ggml.model",8,"llama"),kv("tokenizer.ggml.tokens",9,(8,toks)),
 kv("tokenizer.ggml.scores",9,(6,[0.0]*V)),kv("tokenizer.ggml.token_type",9,(5,types)),
 kv("tokenizer.ggml.bos_token_id",4,1),kv("tokenizer.ggml.eos_token_id",4,4),kv("tokenizer.ggml.unknown_token_id",4,0),
 kv("tokenizer.ggml.add_bos_token",7,True),kv("tokenizer.chat_template",8,tmpl)]
tens=[("token_embd.weight",[D,V]),("output_norm.weight",[D]),("output.weight",[D,V])]
for i in range(L):
    p=f"blk.{i}."
    tens+= [(p+"attn_norm.weight",[D]),(p+"attn_q.weight",[D,D]),(p+"attn_k.weight",[D,D]),(p+"attn_v.weight",[D,D]),
            (p+"attn_output.weight",[D,D]),(p+"ffn_norm.weight",[D]),(p+"ffn_gate.weight",[D,F]),(p+"ffn_up.weight",[D,F]),(p+"ffn_down.weight",[F,D])]
infos=b'';off=0;datas=[]
for n,dims in tens:
    cnt=1
    for d in dims: cnt*=d
    if n.endswith("norm.weight"): arr=[1.0]*cnt
    else: arr=[random.gauss(0,0.08) for _ in range(cnt)]
    data=struct.pack('<%df'%cnt,*arr)
    infos+=s(n)+struct.pack('<I',len(dims))+b''.join(struct.pack('<Q',d) for d in dims)+struct.pack('<IQ',0,off)
    pad=(-len(data))%32; datas.append(data+b'\0'*pad); off+=len(data)+pad
hdr=b'GGUF'+struct.pack('<IQQ',3,len(tens),len(kvs))+b''.join(kvs)+infos
hdr+=b'\0'*((-len(hdr))%32)
open(sys.argv[1],'wb').write(hdr+b''.join(datas))
